[LobbyView Rest API Documentation](https://rest-api.lobbyview.org/)
